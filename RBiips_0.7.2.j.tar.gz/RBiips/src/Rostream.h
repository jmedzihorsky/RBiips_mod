//                                               -*- C++ -*-
/*
 * RBiips package for GNU R is an interface to BiiPS C++ libraries for
 * Bayesian inference with interacting Particle Systems.
 * Copyright (C) Inria, 2012
 * Authors: Adrien Todeschini, Francois Caron
 *
 * RBiips is derived software based on:
 * BiiPS, Copyright (C) Inria, 2012
 * rjags, Copyright (C) Martyn Plummer, 2002-2010
 * Rcpp, Copyright (C) Dirk Eddelbuettel and Romain Francois, 2009-2011
 *
 * This file is part of RBiips.
 *
 * RBiips is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
/*! \file Rostream.h
 * \brief 
 * 
 * \author  $LastChangedBy: todeschi $
 * \date    $LastChangedDate: 2012-04-23 17:33:20 +0200 (lun., 23 avr. 2012) $
 * \version $LastChangedRevision: 299 $
 * Id:      $Id: Rostream.h 299 2012-04-23 15:33:20Z todeschi $
 */

#ifndef ROSTREAM_H_
#define ROSTREAM_H_

#include <ostream>

extern std::ostream rbiips_cout;
extern std::ostream rbiips_cerr;

#endif /* ROSTREAM_H_ */
