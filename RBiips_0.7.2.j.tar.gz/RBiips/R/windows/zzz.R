#                                               -*- R -*-
#
#  RBiips package for GNU R is an interface to BiiPS C++ libraries for
#  Bayesian inference with interacting Particle Systems.
#  Copyright (C) Inria, 2012
#  Authors: Adrien Todeschini, Francois Caron
#  
#  RBiips is derived software based on:
#  BiiPS, Copyright (C) Inria, 2012
#  rjags, Copyright (C) Martyn Plummer, 2002-2010
#  Rcpp, Copyright (C) Dirk Eddelbuettel and Romain Francois, 2009-2011
#
#  This file is part of RBiips.
#
#  RBiips is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#
#  \file     zzz.R
#  \brief    package loading functions for windows
#
#  \author   $LastChangedBy$
#  \date     $LastChangedDate$
#  \version  $LastChangedRevision$
#  Id:       $Id$
#

.findBiiPS <- function(hive, major)
{
  ## Returns the registry key corresponding to the latest release of
  ## BiiPS-major.x.y, or NULL if no release is found
  
  regkey <- try(readRegistry("SOFTWARE\\BiiPS", hive = hive, maxdepth = 2,
                             view="32-bit"), silent = TRUE)
  if (inherits(regkey, "try-error")) {
    return(NULL)
  }
  keynames <- names(regkey)
  keynames <- keynames[grep(paste("^BiiPS-", major, "\\.", sep=""), keynames)]
  if (length(keynames) == 0) {
    return(NULL)
  }
  else {
    regkey <- regkey[keynames]
    for (i in seq(along=keynames)) {
      if (!is.null(regkey[[i]][[1]])) {
        return(regkey[i])
      }
    }
    return(NULL)
  }
}

.noBiiPS <- function(major)
{
  paste("Failed to locate any version of BiiPS version ", major, "\n\n",
        "The RBiips package is just an interface to the BiiPS libraries\n",
        "Make sure you have installed BiiPS-", major,
        ".0.0.exe or higher from\n",
        "http://alea.bordeaux.inria.fr/biips\n", sep="")
}

.onLoad <- function(lib, pkg)
{
### First task is to get installation directory of BiiPS

    ## Try environment variable first
    biips.home <- Sys.getenv("BIIPS_HOME")
    if (nchar(biips.home)==0) {
      ## Search the registry. We need to look for both machine-wide and
      ## user-specific installations

      biips.major <- 0
      
      key1 <- .findBiiPS("HLM", biips.major)
      key2 <- .findBiiPS("HCU", biips.major)

      if (is.null(key1)) {
        if (is.null(key2)) {
          stop(.noBiiPS(biips.major))
        }
        else {
          latest <- key2
        }
      }
      else if (is.null(key2) || names(key2) < names(key1)) {
        latest <- key1
      }
      else {
        latest <- key2
      }

      biips.home <- latest[[1]][[1]]
    }
    
### Add biips.home to the windows PATH, if not already present

    bindir <- file.path(biips.home, .Platform$r_arch, "bin")
    path <- Sys.getenv("PATH")
    split.path <- strsplit(path, .Platform$path.sep)[[1]]
    if (!any(split.path == bindir)) {
        path <- paste(bindir, path, sep=.Platform$path.sep)
        Sys.setenv("PATH"=path)
    }
    
### Set the module directory, if the option biips.moddir is not already set
    
#    if (is.null(getOption("biips.moddir"))) {
#        options("biips.moddir" = file.path(biips.home, .Platform$r_arch,
#                "modules"))
#    }
    library.dynam("RBiips", pkg, lib)
    packageStartupMessage("linking to BiiPS ",
                          .Call("get_version", PACKAGE="RBiips"))
    
    #.Call("init_biips_console", PACKAGE="RBiips")
  
    load.biips.module("basemod")
  
#   set.biips.verbosity(1)
}

.onUnload <- function(libpath)
{
    library.dynam.unload("RBiips", libpath)
}
